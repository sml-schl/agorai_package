"""
Backward compatibility setup.py for agorai package.
Modern configuration is in pyproject.toml.
"""
from setuptools import setup

setup()
